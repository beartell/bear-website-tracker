Sayfalara aşağıdaki javascript eklenecek:

    <!-- Tupraş -->
    <script type="text/javascript">
      var _paq = _paq || [];
      _paq.push(['trackPageView']);
      _paq.push(['enableLinkTracking']);
      (function() {
        var u="//10.1.8.230:8080/";
        _paq.push(['setTrackerUrl', u+'tupras.php']);
        _paq.push(['setSiteId', 'Alarm']);
        _paq.push(['setUserId', '123456']);
        _paq.push(['setNameSurname', 'Mehmet Aydin']);    
        var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
        g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'tupras.js'; s.parentNode.insertBefore(g,s);
      })();
    </script>
    <!-- End Tüpraş Code -->
