; <?php exit; ?>

[database]
url = ["10.10.1.7:9200"]
username = ""
password = ""

[General]
salt = "3014c00769ec6db65234bc8ed4268052"