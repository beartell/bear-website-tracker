<?php
/**
 * Created by PhpStorm.
 * User: miwgates
 * Date: 23.03.2018
 * Time: 17:01
 */

require_once 'vendor/autoload.php';
require_once 'src/Databases/Elastic.php';
require_once 'src/Tracker/Request.php';

use Elasticsearch\ClientBuilder;

$elasticClient = new Elastic();
$request  = new Request($elasticClient);
$request->process();