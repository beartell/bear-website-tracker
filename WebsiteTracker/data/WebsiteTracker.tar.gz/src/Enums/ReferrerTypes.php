<?php
/**
 * Created by PhpStorm.
 * User: miwgates
 * Date: 03.05.2018
 * Time: 14:22
 */

class ReferrerTypes
{
    const REFERRER_TYPE_DIRECT_ENTRY    = "direct";
    const REFERRER_TYPE_SEARCH_ENGINE   = "searchengine";
    const REFERRER_TYPE_WEBSITE         = "website";
    const REFERRER_TYPE_CAMPAIGN        = "campaign";
}