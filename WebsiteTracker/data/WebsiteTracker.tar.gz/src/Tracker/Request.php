<?php
/**
 * Created by PhpStorm.
 * User: miwgates
 * Date: 27.03.2018
 * Time: 16:43
 */

/*
 * Yapılacaklar
 *
 * BrowserLanguage.php sayfasındaki "REFERRER_TYPE_DIRECT_ENTRY" değişkenlernin nasıl çalıştığı araştırılacak.
 *
 * */

require_once 'src/Models/ActionModel.php';
require_once 'src/Models/VisitModel.php';

require_once 'src/Models/VisitorInfoModel.php';
require_once 'src/Models/PageInfoModel.php';
require_once 'src/Models/UserInfoModel.php';
require_once 'src/Models/BrowserInfoModel.php';
require_once 'src/Models/OsInfoModel.php';
require_once 'src/Models/PluginInfoModel.php';

// Enums
require_once 'src/Enums/ReferrerTypes.php';

require_once 'BrowserLanguage.php';

use DeviceDetector\DeviceDetector;


class Request
{
    private $GetVariable = array();
    private $PostVariable = array();
    private $ServerVariable = array();

    private $deviceDetector = null;
    private $elasticClient = null;

    private $processedRequest = null;

    private $timestamp  = 0;
    private $timezone   = Configuration::Timezone;

    static $salt = "0c5070392e6b209c0d8a52948ecf71af";

    public function __construct(Elastic $elasticClient)
    {
        $this->elasticClient = $elasticClient;
    }

    public function process() {
        $this->GetVariable      = $_GET;
        $this->PostVariable     = $_POST;
        $this->ServerVariable   = $_SERVER;

        $this->processedRequest = new ActionModel();
        // Run Detectors
        $this->runDeviceDetector();

        // Original
        $this->processedRequest->original           = $this->GetVariable;
        // Other
        $this->processedRequest->accept_language    = isset($this->ServerVariable['HTTP_ACCEPT_LANGUAGE']) ? $this->ServerVariable['HTTP_ACCEPT_LANGUAGE'] : "";
        $this->timestamp                            = time();
        $this->processedRequest->timestamp          = $this->timestamp;
        $this->processedRequest->application_id     = array("All", isset($this->GetVariable['idsite']) ? $this->GetVariable['idsite'] : 0);
        // Plugin Info
        $this->getPlugisInfo();
        // Page Info
        $this->getPageInfo();
        // User Info
        $this->getUserInfo();
        // Browser Info
        $this->getBrowserInfo();
        // Os Info
        $this->getOsInfo();
        // Visitor Info
        $this->getVisitorInfo();
        //$this->setCachedIfNewVisit();

        // Write Actions
        $this->elasticClient->writeAction($this->processedRequest);
    }


    // Run Functions
    private function runDeviceDetector() {
        $this->deviceDetector = new DeviceDetector(isset($this->ServerVariable['HTTP_USER_AGENT'])? $this->ServerVariable['HTTP_USER_AGENT'] : "");
        $this->deviceDetector->discardBotInformation();
        $this->deviceDetector->parse();
    }


    // Info Functions
    private function getVisitorInfo(){
        $_visitor = new VisitorInfoModel();

        $_visitor->visit_day            = intval(date('d', ($this->timestamp + ($this->timezone*3600))));
        $_visitor->visit_hour           = intval(date('H', ($this->timestamp + ($this->timezone*3600))));
        $_visitor->ip_address           = isset($this->ServerVariable['REMOTE_ADDR']) ? $this->ServerVariable['REMOTE_ADDR'] : "";
        $_visitor->visit_count          = intval(isset($this->GetVariable['t_idvc']) ? $this->GetVariable['t_idvc'] : 0);
        $_visitor->visitor_id           = $this->getVisitorId();
        $_visitor->cookie_visitor_id    = isset($this->GetVariable['t_id']) ? $this->GetVariable['t_id'] : 0;
        $_visitor->is_new_visitor       = boolval(isset($this->GetVariable['t_idn']) ? $this->GetVariable['t_idn'] : 0);

        $this->processedRequest->visitor_info = $_visitor;
    }

    private function getPageInfo(){
        $_pageInfo = new PageInfoModel();

        $_pageInfo->title                   = isset($this->GetVariable['action_name']) ? $this->GetVariable['action_name'] : '';
        $_pageInfo->url                     = isset($this->GetVariable['url']) ? $this->GetVariable['url'] : '';
        $_pageInfo->referrer                = $this->ifNullOrEmptyReturnNope($this->GetVariable['urlref']);
        $_pageInfo->referrer_type           = $this->isDirectEntryOrReferrer($_pageInfo->url, $_pageInfo->referrer);
        $_pageInfo->referral                = $this->ifNullOrEmptyReturnNull($this->GetVariable['t_ref']);
        $_pageInfo->cookie_first_visit_ts   = floatval(isset($this->GetVariable['t_idts']) ? $this->GetVariable['t_idts'] : 0);
        $_pageInfo->last_visit_ts           = floatval(isset($this->GetVariable['t_viewts']) ? $this->GetVariable['t_viewts'] : 0);
        $_pageInfo->generation_time         = intval(isset($this->GetVariable['gt_ms']) ? $this->GetVariable['gt_ms'] : 0);
        $_pageInfo->pageview_id             = isset($this->GetVariable['pv_id']) ? $this->GetVariable['pv_id'] : 0;

        $this->processedRequest->page_info = $_pageInfo;
    }

    private function getUserInfo() {
        $_userInfo = new UserInfoModel();

        $_userInfo->id      = array("All", isset($this->GetVariable["uid"]) ? $this->GetVariable["uid"] : '');
        $_userInfo->name    = array("All", isset($this->GetVariable["name_surname"]) ? $this->GetVariable["name_surname"] : '');

        $this->processedRequest->user_info = $_userInfo;
    }

    private function getBrowserInfo(){
        $_browserInfo   = new BrowserInfoModel();
        $_browser       = $this->deviceDetector->getClient();

        $_browserInfo->engine         = isset($_browser['engine']) ? $_browser['engine'] : '';
        $_browserInfo->engine_version = $this->ifNullOrEmptyReturnUnknown($_browser['engine_version']);
        $_browserInfo->type           = isset($_browser['type']) ? $_browser['type'] : "";
        $_browserInfo->language       = (new BrowserLanguage())->getBrowserLanguage($this->ServerVariable['HTTP_ACCEPT_LANGUAGE']);
        $_browserInfo->name           = !empty($_browser['short_name']) ? $_browser['short_name'] : 'UNK';
        $_browserInfo->short_name     = isset($_browser['short_name']) ? $_browser['short_name'] : '' ;
        $_browserInfo->version        = !empty($_browser['version']) ? floatval($_browser['version']) : 0;
        $_browserInfo->user_agent     = isset($this->ServerVariable['HTTP_USER_AGENT']) ? $this->ServerVariable['HTTP_USER_AGENT'] : '';
        $_browserInfo->resolution     = isset($this->GetVariable['res']) ? $this->GetVariable['res'] : '';

        $this->processedRequest->browser_info = $_browserInfo;
    }

    private function getOsInfo() {
        $_osInfo = new OsInfoModel();

        if ($this->deviceDetector->isBot()) {
            $_osInfo->name          = "BOT";
            $_osInfo->short_name    = "BOT";
        }
        else if($this->deviceDetector->isMobile()){
            $os = $this->deviceDetector->getOS();

            // Base
            $_osInfo->name          = isset($os['name']) ? $os['name'] : "";
            $_osInfo->short_name    = empty($os['short_name']) ? 'UNK' : $os['short_name'];
            $_osInfo->version       = isset($os['version']) ? $os['version'] : "";
            $_osInfo->platform      = $this->ifNullOrEmptyReturnUnknown($os['platform']);
            $_osInfo->is_mobile     = true;

            // Mobil
            $_osInfo->device_name       = $this->deviceDetector->getDeviceName();
            $_osInfo->mobile_brand_name = $this->deviceDetector->getBrandName();
            $_osInfo->mobile_model      = $this->deviceDetector->getModel();
        }
        else {
            $os = $this->deviceDetector->getOS();
            $_osInfo->device_name   = "desktop";
            $_osInfo->name          = isset($os['name']) ? $os['name'] : "";
            $_osInfo->short_name    = empty($os['short_name']) ? 'UNK' : $os['short_name'];
            $_osInfo->version       = isset($os['version']) ? $os['version'] : "";
            $_osInfo->platform      = isset($os['platform']) ? $os['platform'] : "";
        }



        $this->processedRequest->os_info = $_osInfo;
    }

    private function getPlugisInfo() {
        $_pluginInfo = new PluginInfoModel();

        $_pluginInfo->ag        = isset($this->GetVariable["ag"]) ? intval($this->GetVariable["ag"]) : 0;
        $_pluginInfo->cookie    = isset($this->GetVariable["cookie"]) ? intval($this->GetVariable["cookie"]) : 0;
        $_pluginInfo->dir       = isset($this->GetVariable["dir"]) ? intval($this->GetVariable["dir"]) : 0;
        $_pluginInfo->fla       = isset($this->GetVariable["fla"]) ? intval($this->GetVariable["fla"]) : 0;
        $_pluginInfo->gears     = isset($this->GetVariable["gears"]) ? intval($this->GetVariable["gears"]) : 0;
        $_pluginInfo->java      = isset($this->GetVariable["java"]) ? intval($this->GetVariable["java"]) : 0;
        $_pluginInfo->pdf       = isset($this->GetVariable["pdf"]) ? intval($this->GetVariable["pdf"]) : 0;
        $_pluginInfo->qt        = isset($this->GetVariable["qt"]) ? intval($this->GetVariable["qt"]) : 0;
        $_pluginInfo->realp     = isset($this->GetVariable["realp"]) ? intval($this->GetVariable["realp"]) : 0;
        $_pluginInfo->wma       = isset($this->GetVariable["wma"]) ? intval($this->GetVariable["wma"]) : 0;

        $this->processedRequest->plugin_info = $_pluginInfo;
    }


    // Helper Func
    private function getVisitorId() {
        $salt = $this::$salt;
             
        $configString =
            $this->processedRequest->os_info->short_name
            . $this->processedRequest->browser_info->name . $this->processedRequest->browser_info->version
            . $this->processedRequest->plugin_info->fla . $this->processedRequest->plugin_info->java
            . $this->processedRequest->plugin_info->dir . $this->processedRequest->plugin_info->qt
            . $this->processedRequest->plugin_info->realp . $this->processedRequest->plugin_info->pdf
            . $this->processedRequest->plugin_info->wma . $this->processedRequest->plugin_info->gears
            . $this->processedRequest->plugin_info->ag . $this->processedRequest->plugin_info->cookie
            . $this->processedRequest->visitor_info->ip_address
            . $this->processedRequest->browser_info->language
            . $salt;

        return md5($configString, $raw_output = false);
    }
    private function ifNullOrEmptyReturnNope($data)
    {
        if (trim($data) === "" or $data === null or empty($data))
            return "Nope";

        return $data;
    }
    private function ifNullOrEmptyReturnNull($data)
    {
        if (trim($data) === "" or $data === null or empty($data))
            return "Nope";

        return $data;
    }
    private function ifNullOrEmptyReturnUnknown($data)
    {
        if (trim($data) === "" or $data === null or empty($data))
            return "Unknown";

        return $data;
    }
    private function isDirectEntryOrReferrer($url, $referrer) {
        if(empty($referrer) or trim($referrer) == "" or $referrer == null){
            return ReferrerTypes::REFERRER_TYPE_WEBSITE;
        } else if(strcmp($url, $referrer) == 0) {
            return ReferrerTypes::REFERRER_TYPE_WEBSITE;
        }

        return ReferrerTypes::REFERRER_TYPE_DIRECT_ENTRY;
    }
    private function setCachedIfNewVisit() {

        $visitInfo = $this->elasticClient->getLastVisitInfo($this->processedRequest->application_id,
            $this->processedRequest->visitor_info->visitor_id,
            $this->processedRequest->visitor_info->ip_address);

        // New Visitor
        if($visitInfo == null) {
            $this->processedRequest->visitor_info->is_cached = true;
        }
        // Old Visitor
        else {
            $nowTimeStamp = time() * 1000;

            if ($nowTimeStamp >= $visitInfo['timestamp'] + 1800000) {
                $this->processedRequest->visitor_info->is_cached = true;
            }
        }
    }
}

