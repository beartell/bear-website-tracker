<?php
/**
 * Created by PhpStorm.
 * User: miwgates
 * Date: 28.03.2018
 * Time: 14:50
 */

class OsInfoModel
{
    // Base
    public $device_name = "";
    public $name = "";
    public $platform = "";
    public $short_name = "";
    public $version = "";
    public $is_mobile = false;

    // Is Mobil
    public $mobile_brand_name = "Unknown";
    public $mobile_model = "Unknown";
}