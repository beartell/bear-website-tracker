<?php
/**
 * Created by PhpStorm.
 * User: miwgates
 * Date: 26.04.2018
 * Time: 17:48
 */

class OriginalModel
{
    public $name_surname = "";
    public $uid = "";

    public $t_id = "";
    public $t_idn = "";
    public $t_idts = "";
    public $t_idvc = "";
    public $t_ref = "";
    public $t_refts = "";
    public $t_viewts = "";

    public $action_name = "";
    public $cs = "";
    public $gt_ms = "";
    public $h = "";
    public $idsite = "";
    public $link = "";
    public $m = "";
    public $pv_id = "";
    public $r = "";
    public $rec = "";
    public $res = "";
    public $s = "";
    public $send_image = "";
    public $url = "";
    public $urlref = "";

    public $ag = "";
    public $cookie = "";
    public $dir = "";
    public $fla = "";
    public $gears = "";
    public $java = "";
    public $pdf = "";
    public $qt = "";
    public $realp = "";
    public $wma = "";


}