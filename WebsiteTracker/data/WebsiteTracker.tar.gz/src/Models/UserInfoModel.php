<?php
/**
 * Created by PhpStorm.
 * User: miwgates
 * Date: 26.04.2018
 * Time: 17:49
 */

class UserInfoModel
{
    public $id = "";
    public $name = "";
}