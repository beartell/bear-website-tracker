<?php
/**
 * Created by PhpStorm.
 * User: miwgates
 * Date: 26.04.2018
 * Time: 17:48
 */

class PageInfoModel
{
    public $title = "";
    public $url = "";
    public $referrer = null;
    public $referrer_type = null;
    public $referral = null;
    public $cookie_first_visit_ts = null;
    public $last_visit_ts = null;
    public $generation_time = 0;
    public $pageview_id = "";
}