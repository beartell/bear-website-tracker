<?php
/**
 * Created by PhpStorm.
 * User: miwgates
 * Date: 26.04.2018
 * Time: 17:48
 */

class VisitorInfoModel
{
    public $visit_day = 0;
    public $visit_hour = 0;
    public $visit_count = 0;
    public $visitor_id = "";
    public $ip_address = "";
    public $cookie_visitor_id = "";
    public $is_new_visitor = false;
    public $is_cached = false;
}