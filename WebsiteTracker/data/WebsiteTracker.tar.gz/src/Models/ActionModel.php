<?php
/**
 * Created by PhpStorm.
 * User: miwgates
 * Date: 27.04.2018
 * Time: 11:38
 */

class ActionModel
{
    public $original = null;
    public $application_id = null;
    public $accept_language = null;
    public $timestamp = null;
    public $visitor_info = null;
    public $page_info = null;
    public $user_info = null;
    public $browser_info = null;
    public $os_info = null;
    public $plugin_info = null;
}