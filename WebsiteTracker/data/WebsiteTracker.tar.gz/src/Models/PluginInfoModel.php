<?php
/**
 * Created by PhpStorm.
 * User: miwgates
 * Date: 26.04.2018
 * Time: 17:49
 */

class PluginInfoModel
{
    public $fla = 0;
    public $java = 0;
    public $dir = 0;
    public $qt = 0;
    public $realp = 0;
    public $pdf = 0;
    public $wma = 0;
    public $gears = 0;
    public $ag = 0;
    public $cookie = 0;
}