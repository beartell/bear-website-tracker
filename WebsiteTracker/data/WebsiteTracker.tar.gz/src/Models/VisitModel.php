<?php
/**
 * Created by PhpStorm.
 * User: miwgates
 * Date: 03.05.2018
 * Time: 17:38
 */

class VisitModel
{
    public $application_id = null;
    public $timestamp = null;
    public $visitor_info = null;
    public $user_info = null;

}