<?php
/**
 * Created by PhpStorm.
 * User: miwgates
 * Date: 28.03.2018
 * Time: 14:36
 */

class BrowserInfoModel
{
    public $engine = "";
    public $engine_version = 0.0;
    public $type = 0.0;
    public $language = "";
    public $name = "";
    public $short_name = "";
    public $version = 0.0;
    public $user_agent = "";
    public $resolution = "";
}

