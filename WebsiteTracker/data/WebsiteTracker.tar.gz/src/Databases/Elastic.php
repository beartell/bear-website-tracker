<?php
/**
 * Created by PhpStorm.
 * User: miwgates
 * Date: 23.03.2018
 * Time: 17:26
 */

require_once 'src/Configuration.php';

use Elasticsearch\ClientBuilder;

class Elastic
{
    private $client = null;

    public function __construct()
    {
        $this->client = ClientBuilder::create()->setHosts(Configuration::ElasticsearchHosts)->setRetries(0)->build();
    }

    public function writeAction($body) {
        $params = [
            'index' => Configuration::ESActionIndice,
            'type' => '_doc',
            'body' => $body
        ];

        $this->client->index($params);
    }

    public function writeVisit($body) {
        $params = [
            'index' => Configuration::ESVisitIndice,
            'type' => '_doc',
            'body' => $body
        ];

        $this->client->index($params);
    }

    public function getLastVisitInfo($application_id, $visitor_id, $ip) {
        $gteTime = time()-3600000;

        $params = [
            'index' => $this->actionIndex,
            'type' => '_doc',
            'body' => [
                '_source' => ['timestamp', 'visitor_info'],
                'query' => [
                    'bool' => [
                        'must' => [
                            [ 'match' => [ 'application_id' => $application_id ] ],
                            [ 'match' => [ 'visitor_info.visitor_id' => $visitor_id ] ],
                            [ 'match' => [ 'visitor_info.ip_address' => $ip ] ],
                            [ 'match' => [ 'visitor_info.is_cached' => true ] ]
                        ],
                        'filter' => [
                            'range' => [
                                'timestamp' => [
                                    'gte' => $gteTime
                                ]
                            ]
                        ]
                    ]
                ],
                'sort' => [
                    ['timestamp' => ['order' => 'desc']]
                ]
            ]
        ];

        $results = $this->client->search($params);

        if($results['hits']['total'] > 0)
            return $results['hits']['hits'][0]['_source'];

        return null;
    }

}