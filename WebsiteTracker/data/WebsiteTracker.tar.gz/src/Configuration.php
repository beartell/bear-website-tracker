<?php
/**
 * Created by PhpStorm.
 * User: miwgates
 * Date: 10.05.2018
 * Time: 16:26
 */

class Configuration
{
    const ElasticsearchHosts = ["127.0.0.1:9200"];
    const ESActionIndice = "action";
    const ESVisitIndice = "visit";

    const Timezone = 3;
}
